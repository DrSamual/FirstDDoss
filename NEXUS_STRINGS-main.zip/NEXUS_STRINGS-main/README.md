# NEXUS_STRINGS
A Most Java Powerful DDoS 
<img width="99.9%" src="https://github.com/Mr-Cyb3rgh0st/DDos-Tool/blob/main/src/Mr_Cyb3rghost.png"/>



> DDos-Tool was created to destroy Indian Wedsite, this script is very powerful!

---
#### Features
- [x] Fast ddos
- [x] Free proxy
- [x] Supported on java
- [x] Supported other systems
- [x] Quickly and clearly
- [x] Functionality


----

### kali Installing

* `sudo apt update`
* `sudo apt upgrade`
* `sudo apt install git`
* `sudo apt install default-jdk `

* `https://github.com/us-nexus-hackers/NEXUS_STRINGS.git`

### Installing

* `pkg update`
* `pkg upgrade`
* `pkg install git`
* `pkg install openjdk-17`
* `https://github.com/us-nexus-hackers/NEXUS_STRINGS`



#### Finished you have successfully downloaded DDos-Tool now to launch!

* `cd NEXUS_STRINGS`
* `java ddos-attack.java`

-----
## Dependencies

```
Wifi   : True
Root   : No Root
Package: 610 kB
```

------



-------

<br>
<p align="center">
<img width="100%" src="https://github.com/Mr-Cyb3rgh0st/DDos-Tool/blob/main/src/screenshot.png"/> 
</p>

--------


